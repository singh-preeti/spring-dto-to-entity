package com.transaction.SpringTransactionDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTransactionDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
